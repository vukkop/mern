import React from 'react'
import ProductDetails from '../components/ProductDetails'


const SinglePorduct = (props) => {

  return (
    <div>

      <ProductDetails />

    </div>
  )
}

export default SinglePorduct
