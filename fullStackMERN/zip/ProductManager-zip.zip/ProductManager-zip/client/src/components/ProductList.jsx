import React, { useEffect, useState } from "react";
import axios from "axios";

const ProductList = () => {
  const [productList, setProductList] = useState([]);
  useEffect(() => {
    axios
      .get("http://localhost:8000/api/products/all")
      .then((res) => {
        setProductList(res.data)
      });
  }, []);




  return (
    <div>
      <div>ProductList</div>


      <table border={'border = 1px'}>
        <thead>
          <tr>
            <th>Title</th>
            <th>Price</th>
            <th>Description</th>
          </tr>
        </thead>
        <tbody>
          {productList.map((e, i) =>
            <tr key={i}>
              <td>{e.title}</td>
              <td>{e.price}</td>
              <td>{e.description}</td>
              <td>{e.createdAt}</td>

            </tr>
          )}
        </tbody>
      </table>

    </div >
  )
}

export default ProductList
