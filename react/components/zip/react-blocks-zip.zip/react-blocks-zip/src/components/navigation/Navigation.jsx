import React from 'react'
import './Navigation.style.css'

const Navigation = () => {
  return (
    <div className="Navigation">Navigation</div>
  )
}

export default Navigation
