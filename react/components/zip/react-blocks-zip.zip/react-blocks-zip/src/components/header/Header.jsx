import React from 'react'
import './Header.style.css'

const Header = () => {
  return (
    <div className="Header">Header</div>
  )
}

export default Header
