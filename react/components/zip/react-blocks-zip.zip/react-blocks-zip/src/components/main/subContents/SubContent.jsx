import React from 'react'
import './SubContent.style.css'

const SubContent = () => {
  return (
    <div className='SubContent'>SubContent</div>
  )
}

export default SubContent
