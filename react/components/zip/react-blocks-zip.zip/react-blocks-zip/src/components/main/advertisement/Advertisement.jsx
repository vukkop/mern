import React from 'react'
import './Advertisement.style.css'

const Advertisement = () => {
  return (
    <div className='Advertisement'>Advertisement</div>
  )
}

export default Advertisement
