import "./App.css";
import DataForm from "./components/DataForm";

function App() {
  return (
    <div className="App">
      <DataForm />
    </div>
  );
}

export default App;
